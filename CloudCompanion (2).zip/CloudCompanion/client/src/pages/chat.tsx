import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { ChatWindow } from "@/components/chat/chat-window";

export default function Chat() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-mws-blue to-mws-blue/95 p-4">
      <div className="container mx-auto py-8">
        <Card className="mb-8 border-2 border-mws-orange/20 shadow-xl bg-white/95">
          <CardHeader className="space-y-2">
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-mws-orange to-mws-blue bg-clip-text text-transparent">
              MWS Customer Support
            </CardTitle>
            <CardDescription className="text-mws-blue/80">
              Welcome to Million Web Services! How can we help you with our cloud computing, IT services, or digital marketing solutions today?
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ChatWindow />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}