import { apiRequest } from "./queryClient";
import type { Message } from "@shared/schema";

export async function sendMessage(content: string, sessionId: string): Promise<{userMessage: Message, botMessage: Message}> {
  try {
    const res = await apiRequest("POST", "/api/chat", { content, sessionId });
    const data = await res.json();
    if (!data.userMessage || !data.botMessage) {
      throw new Error("Invalid response format from server");
    }
    return data;
  } catch (error) {
    console.error("Error sending message:", error);
    throw error;
  }
}