import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { nanoid } from "nanoid";
import { ChatMessage } from "./chat-message";
import { ChatInput } from "./chat-input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { sendMessage } from "@/lib/api";
import type { Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function ChatWindow() {
  const [sessionId] = useState(() => nanoid());
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: messages = [], isError } = useQuery<Message[]>({
    queryKey: [`/api/messages/${sessionId}`],
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load messages",
        variant: "destructive"
      });
    }
  });

  const mutation = useMutation({
    mutationFn: async (content: string) => {
      return sendMessage(content, sessionId);
    },
    onSuccess: (data) => {
      // Add new messages to the cache immediately
      queryClient.setQueryData<Message[]>([`/api/messages/${sessionId}`], (old = []) => {
        return [...old, data.userMessage, data.botMessage];
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  useEffect(() => {
    const el = document.getElementById("chat-messages");
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages]);

  if (isError) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-destructive">Failed to load chat messages</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[600px] max-w-3xl mx-auto">
      <ScrollArea id="chat-messages" className="flex-1 p-4">
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
        {mutation.isPending && (
          <div className="flex justify-start">
            <div className="animate-pulse bg-muted rounded p-4">
              <div className="h-4 w-20 bg-muted-foreground/20 rounded"></div>
            </div>
          </div>
        )}
      </ScrollArea>
      <div className="p-4 border-t">
        <ChatInput 
          onSend={(content) => mutation.mutate(content)}
          disabled={mutation.isPending}
        />
      </div>
    </div>
  );
}