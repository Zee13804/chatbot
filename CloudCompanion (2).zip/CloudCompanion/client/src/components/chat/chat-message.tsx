import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { Message } from "@shared/schema";
import { Bot, User } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  return (
    <div className={cn("flex gap-3 mb-4", message.isBot ? "justify-start" : "justify-end")}>
      {message.isBot && (
        <div className="w-8 h-8 rounded-full bg-mws-blue flex items-center justify-center">
          <Bot className="w-4 h-4 text-white" />
        </div>
      )}
      <Card className={cn(
        "max-w-[80%] p-4 shadow-md",
        message.isBot ? "bg-white border-mws-blue/10" : "bg-gradient-to-r from-mws-orange to-mws-orange/90 text-white"
      )}>
        <div className={cn(
          "text-sm leading-relaxed prose-sm max-w-none",
          message.isBot ? "prose" : "text-white"
        )}>
          {message.isBot ? (
            <ReactMarkdown
              components={{
                ul: ({ children }) => <ul className="list-disc list-inside space-y-1">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal list-inside space-y-1">{children}</ol>,
                li: ({ children }) => <li className="my-0">{children}</li>,
                strong: ({ children }) => <span className="font-semibold">{children}</span>,
                p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>
              }}
            >
              {message.content}
            </ReactMarkdown>
          ) : (
            <p>{message.content}</p>
          )}
        </div>
      </Card>
      {!message.isBot && (
        <div className="w-8 h-8 rounded-full bg-mws-orange flex items-center justify-center">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}