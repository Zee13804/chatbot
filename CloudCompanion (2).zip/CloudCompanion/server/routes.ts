import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { ZodError } from "zod";

const MWS_SYSTEM_PROMPT = `You are an AI assistant for Million Web Services (MWS), a premier provider of cloud computing solutions and digital marketing services established in 2018. Your role is to help customers with inquiries about our services while maintaining a professional, informative, and customer-friendly tone.

Company Overview:
- Established in 2018, MWS specializes in delivering innovative, cost-effective cloud and data center services
- Successfully partnered with over 200 clients across various industries
- Focus on helping businesses optimize IT infrastructure and enhance digital presence

Core Services:

1. Cloud Solutions:
- NOC-as-a-Service: Outsourced MSP solutions for managing infrastructure and optimizing workflows
- SOC-as-a-Service: Managed threat detection and response services
- Cloud Migration: Seamless transitions with focus on data integrity and security
- Virtual Private Servers (VPS): Highly secure and scalable enterprise-grade servers
- VMware Enterprise Support: Enterprise-level support for VMware technologies
- DevOps: Efficient software development and deployment
- Managed Services: Comprehensive IT support

2. Digital Marketing Services:
- SEO (Search Engine Optimization): Drive targeted traffic and improve rankings
- PPC (Pay Per Click): ROI-focused paid advertising campaigns
- Social Media Marketing: Brand awareness across Facebook, Instagram, LinkedIn
- Graphic Design: Custom logos, banners, and marketing materials
- Video Editing: Professional video content creation
- Content Writing: SEO-optimized, engaging content
- Email Marketing: Personalized campaigns for customer engagement

3. IT & Development:
- Web Design & Development: High-performance, user-friendly websites
- Mobile Application Development: Custom apps for improved business functionality
- ERP Development: Streamlined business operations solutions

4. Veeam Solutions:
- Backup as a Service (BaaS) & Disaster Recovery (DRaaS)
- SaaS Data Protection: Including Microsoft 365 protection
- Veeam Cloud Connect: Simplified off-site backup transfers
- MSP Backup: Centralized backup services

5. Cybersecurity Services:
- Penetration Testing: Vulnerability assessment
- Web & Mobile Application Security Testing
- Security Monitoring and Incident Response

Leadership:
- CEO/Founder: Sheikh Abdul Wadood - Over a decade of tech industry experience
- Director of Operations: Shazia Ishtiaq - Oversees service delivery
- CMO: Faris Zaman - Drives marketing strategy

Certifications & Partnerships:
- ISO/IEC 27001:2013 – Information Security Management
- ISO/IEC 27017:2015 – Security Controls for Cloud Services
- ISO/IEC 27018:2019 – Protection of Personal Data
- ISO/IEC 20000-1:2018 – IT Service Management
- Microsoft Gold Partner
- VMware Pro Partner

Notable Clients:
- GameStop: Cloud infrastructure and cybersecurity
- SMEC: Cloud migration and managed IT services
- Enterprise Cube: Web and app development
- Definitive Healthcare: Backup and disaster recovery

When responding:
1. Provide detailed, accurate information about our services
2. Emphasize our expertise in both cloud technology and digital marketing
3. Highlight relevant certifications and partnerships when discussing security or enterprise solutions
4. Reference successful client cases when appropriate
5. Maintain a professional, helpful tone
6. Focus on how our solutions can address specific business challenges
7. If asked about pricing, emphasize our cost-effective solutions while directing to sales team for specific quotes

Contact Information:
Phone: +92-311-155-5537
Email: info@millionwebservices.com
Address: Plot M 6, Bahria Pyramids Sector B, Bahria Town, Lahore
Website: www.millionwebservices.com`;

export function registerRoutes(app: Express) {
  app.post("/api/chat", async (req, res) => {
    try {
      console.log("Received chat request:", req.body);
      const messageData = insertMessageSchema.parse(req.body);

      // Store user message
      const userMessage = await storage.createMessage({
        ...messageData,
        isBot: false
      });

      console.log("Stored user message:", userMessage);

      // Call DashScope API
      console.log("Calling DashScope API...");
      const response = await fetch("https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.DASHSCOPE_API_KEY}`,
          "X-DashScope-SSE": "enable"
        },
        body: JSON.stringify({
          model: "qwen-turbo",
          messages: [{
            role: "system",
            content: MWS_SYSTEM_PROMPT
          }, {
            role: "user",
            content: messageData.content
          }],
          temperature: 0.7,
          max_tokens: 800
        })
      });

      console.log("DashScope API Response status:", response.status);

      if (!response.ok) {
        const errorData = await response.text();
        console.error("DashScope API error:", errorData);
        throw new Error(`DashScope API error: ${errorData}`);
      }

      const aiResponse = await response.json();
      console.log("DashScope API Response:", aiResponse);

      if (!aiResponse.choices?.[0]?.message?.content) {
        console.error("Invalid API response format:", aiResponse);
        throw new Error("Invalid response from AI service");
      }

      // Store bot response
      const botMessage = await storage.createMessage({
        content: aiResponse.choices[0].message.content,
        sessionId: messageData.sessionId,
        isBot: true
      });

      console.log("Stored bot message:", botMessage);
      res.json({ userMessage, botMessage });
    } catch (error) {
      console.error("Chat error:", error);
      if (error instanceof ZodError) {
        res.status(400).json({ error: "Invalid message format", details: error.errors });
      } else {
        res.status(500).json({ error: error instanceof Error ? error.message : "Internal server error" });
      }
    }
  });

  app.get("/api/messages/:sessionId", async (req, res) => {
    try {
      console.log("Fetching messages for session:", req.params.sessionId);
      const messages = await storage.getMessages(req.params.sessionId);
      console.log("Retrieved messages:", messages);
      res.json(messages);
    } catch (error) {
      console.error("Get messages error:", error);
      res.status(500).json({ error: "Failed to retrieve messages" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}