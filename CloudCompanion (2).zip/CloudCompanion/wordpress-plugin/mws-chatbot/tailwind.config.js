/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        mws: {
          orange: "#FF7300",
          blue: "#1E365A"
        }
      }
    },
  },
  plugins: [
    require('@tailwindcss/typography')
  ],
  corePlugins: {
    preflight: false, // Disable base styles to prevent conflicts with WordPress themes
  },
}