<?php
/**
 * Plugin Name: MWS Chatbot
 * Plugin URI: https://millionwebservices.com
 * Description: A professional AI chatbot powered by DashScope for MWS customer support
 * Version: 1.0.0
 * Author: Million Web Services
 * Author URI: https://millionwebservices.com
 * Text Domain: mws-chatbot
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MWS_CHATBOT_VERSION', '1.0.0');
define('MWS_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MWS_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Admin settings page
function mws_chatbot_add_settings_page() {
    add_options_page(
        'MWS Chatbot Settings',
        'MWS Chatbot',
        'manage_options',
        'mws-chatbot-settings',
        'mws_chatbot_settings_page'
    );
}
add_action('admin_menu', 'mws_chatbot_add_settings_page');

// Register settings
function mws_chatbot_register_settings() {
    register_setting('mws-chatbot-settings-group', 'mws_chatbot_api_key');
    register_setting('mws-chatbot-settings-group', 'mws_chatbot_position', array(
        'type' => 'string',
        'default' => 'bottom-left'
    ));
}
add_action('admin_init', 'mws_chatbot_register_settings');

// Settings page HTML
function mws_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h2>MWS Chatbot Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('mws-chatbot-settings-group'); ?>
            <?php do_settings_sections('mws-chatbot-settings-group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">DashScope API Key</th>
                    <td>
                        <input type="text" 
                               name="mws_chatbot_api_key" 
                               value="<?php echo esc_attr(get_option('mws_chatbot_api_key')); ?>" 
                               class="regular-text"
                        />
                        <p class="description">Enter your DashScope API key here</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chat Widget Position</th>
                    <td>
                        <select name="mws_chatbot_position">
                            <option value="bottom-left" <?php selected(get_option('mws_chatbot_position'), 'bottom-left'); ?>>Bottom Left</option>
                            <option value="bottom-right" <?php selected(get_option('mws_chatbot_position'), 'bottom-right'); ?>>Bottom Right</option>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Enqueue scripts and styles
function mws_chatbot_enqueue_scripts() {
    // Only enqueue on frontend
    if (is_admin()) {
        return;
    }

    wp_enqueue_style(
        'mws-chatbot-styles',
        MWS_CHATBOT_PLUGIN_URL . 'dist/css/chat.css',
        array(),
        MWS_CHATBOT_VERSION
    );

    wp_enqueue_script(
        'mws-chatbot-script',
        MWS_CHATBOT_PLUGIN_URL . 'dist/js/chat.js',
        array('wp-element'),
        MWS_CHATBOT_VERSION,
        true
    );

    wp_localize_script('mws-chatbot-script', 'mwsChatbotSettings', array(
        'apiUrl' => rest_url('mws-chatbot/v1'),
        'nonce' => wp_create_nonce('wp_rest'),
        'position' => get_option('mws_chatbot_position', 'bottom-left')
    ));
}
add_action('wp_enqueue_scripts', 'mws_chatbot_enqueue_scripts');

// Register REST API endpoints
function mws_chatbot_register_routes() {
    register_rest_route('mws-chatbot/v1', '/chat', array(
        'methods' => 'POST',
        'callback' => 'mws_chatbot_handle_chat',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'mws_chatbot_register_routes');

// Handle chat REST endpoint
function mws_chatbot_handle_chat($request) {
    $api_key = get_option('mws_chatbot_api_key');
    if (!$api_key) {
        return new WP_Error('no_api_key', 'DashScope API key is not configured', array('status' => 500));
    }

    $parameters = $request->get_json_params();
    $content = sanitize_text_field($parameters['content']);
    $session_id = sanitize_text_field($parameters['sessionId']);

    $response = wp_remote_post('https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions', array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
            'X-DashScope-SSE' => 'enable'
        ),
        'body' => json_encode(array(
            'model' => 'qwen-turbo',
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => file_get_contents(MWS_CHATBOT_PLUGIN_DIR . 'system-prompt.txt')
                ),
                array(
                    'role' => 'user',
                    'content' => $content
                )
            ),
            'temperature' => 0.7,
            'max_tokens' => 800
        ))
    ));

    if (is_wp_error($response)) {
        return new WP_Error('api_error', $response->get_error_message(), array('status' => 500));
    }

    $body = json_decode(wp_remote_retrieve_body($response));

    return array(
        'userMessage' => array(
            'content' => $content,
            'sessionId' => $session_id,
            'isBot' => false
        ),
        'botMessage' => array(
            'content' => $body->choices[0]->message->content,
            'sessionId' => $session_id,
            'isBot' => true
        )
    );
}

// Add chatbot container to footer
function mws_chatbot_add_container() {
    echo '<div id="mws-chatbot-container"></div>';
}
add_action('wp_footer', 'mws_chatbot_add_container');

// Add settings link on plugin page
function mws_chatbot_add_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=mws-chatbot-settings">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'mws_chatbot_add_settings_link');

// Load text domain for translations
function mws_chatbot_load_textdomain() {
    load_plugin_textdomain('mws-chatbot', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'mws_chatbot_load_textdomain');