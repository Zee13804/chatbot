# MWS Chatbot WordPress Plugin

A professional AI chatbot powered by DashScope for MWS customer support.

## Installation

1. Build the plugin:
```bash
# Install dependencies
npm install

# Build the plugin
npm run build
```

2. Install in WordPress:
- Go to WordPress admin panel
- Navigate to Plugins > Add New > Upload Plugin
- Upload the zipped plugin folder
- Activate the plugin

3. Configuration:
- Go to Settings > MWS Chatbot
- Enter your DashScope API key
- Save changes

4. Usage:
- Add the chatbot to any page or post using the shortcode: `[mws_chatbot]`
- The chatbot will automatically use MWS brand colors
- The chat interface is responsive and works on all devices

## Features

- Professional AI-powered customer support
- Seamless WordPress integration
- Responsive design with MWS brand colors
- Real-time chat interface
- Secure API key management
- Easy installation and configuration

## Support

For support or questions, please contact:
- Email: info@millionwebservices.com
- Phone: +92-311-155-5537
