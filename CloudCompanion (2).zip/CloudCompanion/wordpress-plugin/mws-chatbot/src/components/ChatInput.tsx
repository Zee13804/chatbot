import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSend(message);
      setMessage("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message here..."
        className="flex-1 min-h-[60px] p-2 rounded-lg border border-gray-300 focus:border-mws-orange/50 focus:ring-1 focus:ring-mws-orange/50 resize-none"
        disabled={disabled}
      />
      <button 
        type="submit" 
        disabled={disabled || !message.trim()}
        className={`px-4 py-2 rounded-lg bg-mws-orange text-white hover:bg-mws-orange/90 disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        <Send className="w-4 h-4" />
      </button>
    </form>
  );
}
