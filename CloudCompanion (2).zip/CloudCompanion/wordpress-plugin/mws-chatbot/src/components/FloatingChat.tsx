import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { Chat } from './Chat';

export function FloatingChat() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {isOpen ? (
        <div className="relative">
          <div className="absolute bottom-0 left-0 w-[calc(100vw-2rem)] sm:w-[400px] rounded-lg shadow-2xl">
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-2 right-2 z-10 p-2 rounded-full hover:bg-gray-100"
              aria-label="Close chat"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
            <Chat />
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-mws-orange hover:bg-mws-orange/90 text-white p-4 rounded-full shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-110"
          aria-label="Open chat"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
