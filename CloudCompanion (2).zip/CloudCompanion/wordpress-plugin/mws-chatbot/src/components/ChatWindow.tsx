import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { nanoid } from 'nanoid';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';

interface Message {
  content: string;
  sessionId: string;
  isBot: boolean;
}

interface ChatWindowProps {
  apiUrl: string;
  nonce: string;
}

export function ChatWindow({ apiUrl, nonce }: ChatWindowProps) {
  const [sessionId] = useState(() => nanoid());
  const queryClient = useQueryClient();

  const { data: messages = [], isError } = useQuery({
    queryKey: [`${apiUrl}/messages/${sessionId}`],
    onError: (error) => {
      console.error('Failed to fetch messages:', error);
    }
  });

  const mutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await fetch(`${apiUrl}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': nonce
        },
        body: JSON.stringify({ content, sessionId })
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData<Message[]>([`${apiUrl}/messages/${sessionId}`], (old = []) => {
        return [...old, data.userMessage, data.botMessage];
      });
    },
    onError: (error) => {
      console.error('Failed to send message:', error);
    }
  });

  useEffect(() => {
    const el = document.getElementById('chat-messages');
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages]);

  if (isError) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-destructive">Failed to load chat messages</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[600px]">
      <div id="chat-messages" className="flex-1 p-4 overflow-y-auto">
        {messages?.map((message: Message, index: number) => (
          <ChatMessage key={index} message={message} />
        ))}
        {mutation.isPending && (
          <div className="flex justify-start">
            <div className="animate-pulse bg-muted rounded p-4">
              <div className="h-4 w-20 bg-muted-foreground/20 rounded"></div>
            </div>
          </div>
        )}
      </div>
      <div className="p-4 border-t">
        <ChatInput 
          onSend={(content) => mutation.mutate(content)}
          disabled={mutation.isPending}
        />
      </div>
    </div>
  );
}