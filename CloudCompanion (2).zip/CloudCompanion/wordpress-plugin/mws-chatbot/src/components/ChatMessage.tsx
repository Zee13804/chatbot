import React from 'react';
import { Bot, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Message {
  content: string;
  isBot: boolean;
}

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  return (
    <div className={`flex gap-3 mb-4 ${message.isBot ? "justify-start" : "justify-end"}`}>
      {message.isBot && (
        <div className="w-8 h-8 rounded-full bg-mws-blue flex items-center justify-center">
          <Bot className="w-4 h-4 text-white" />
        </div>
      )}
      <div className={`max-w-[80%] p-4 rounded-lg shadow-md ${
        message.isBot 
          ? "bg-white border border-mws-blue/10" 
          : "bg-gradient-to-r from-mws-orange to-mws-orange/90 text-white"
      }`}>
        <div className="text-sm whitespace-pre-wrap leading-relaxed prose prose-sm max-w-none">
          {message.isBot ? (
            <ReactMarkdown
              components={{
                h1: ({node, ...props}) => <h1 className="text-lg font-bold mb-2" {...props} />,
                h2: ({node, ...props}) => <h2 className="text-base font-bold mb-2" {...props} />,
                h3: ({node, ...props}) => <h3 className="text-base font-semibold mb-1" {...props} />,
                h4: ({node, ...props}) => <h4 className="text-sm font-semibold mb-1" {...props} />,
                p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                ul: ({node, ...props}) => <ul className="list-disc ml-4 mb-2" {...props} />,
                ol: ({node, ...props}) => <ol className="list-decimal ml-4 mb-2" {...props} />,
                li: ({node, ...props}) => <li className="mb-1" {...props} />,
                strong: ({node, ...props}) => <strong className="font-semibold" {...props} />,
              }}
            >
              {message.content}
            </ReactMarkdown>
          ) : (
            <p>{message.content}</p>
          )}
        </div>
      </div>
      {!message.isBot && (
        <div className="w-8 h-8 rounded-full bg-mws-orange flex items-center justify-center">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}