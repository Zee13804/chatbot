import React from 'react';
import { nanoid } from 'nanoid';
import { ChatWindow } from './ChatWindow';

declare const mwsChatbotSettings: {
  apiUrl: string;
  nonce: string;
};

export function Chat() {
  return (
    <div className="mws-chatbot-wrapper bg-gradient-to-b from-mws-blue to-mws-blue/95 p-4 rounded-lg shadow-xl">
      <div className="bg-white/95 rounded-lg p-4 border-2 border-mws-orange/20">
        <div className="space-y-2 mb-4">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-mws-orange to-mws-blue bg-clip-text text-transparent">
            MWS Customer Support
          </h2>
          <p className="text-mws-blue/80">
            Welcome to Million Web Services! How can we help you with our cloud computing, IT services, or digital marketing solutions today?
          </p>
        </div>
        <ChatWindow apiUrl={mwsChatbotSettings.apiUrl} nonce={mwsChatbotSettings.nonce} />
      </div>
    </div>
  );
}
