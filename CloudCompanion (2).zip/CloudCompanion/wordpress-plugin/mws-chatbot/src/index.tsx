import React from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { FloatingChat } from './components/FloatingChat';
import './styles/index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

// Wait for DOM content to be loaded
document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('mws-chatbot-container');
  if (container) {
    const root = createRoot(container);
    root.render(
      <React.StrictMode>
        <QueryClientProvider client={queryClient}>
          <FloatingChat />
        </QueryClientProvider>
      </React.StrictMode>
    );
  }
});